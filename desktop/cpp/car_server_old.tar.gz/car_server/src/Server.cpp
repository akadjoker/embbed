#include "Server.hpp"
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <stdexcept>
#include <iostream>

namespace CarServer
{
    namespace Network
    {

        Server::Server(uint16_t port)
            : port_(port), running_(false), car_state_(std::make_shared<Car::CarState>())
        {

            server_socket_ = socket(AF_INET, SOCK_STREAM, 0);
            if (server_socket_ < 0)
            {
                throw std::runtime_error("Failed to create socket");
            }

            int opt = 1;
            setsockopt(server_socket_, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

            sockaddr_in server_addr{};
            server_addr.sin_family = AF_INET;
            server_addr.sin_addr.s_addr = INADDR_ANY;
            server_addr.sin_port = htons(port_);

            if (bind(server_socket_, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0)
            {
                throw std::runtime_error("Failed to bind");
            }

            if (listen(server_socket_, 5) < 0)
            {
                throw std::runtime_error("Failed to listen");
            }
        }

        void Server::start()
        {
            running_ = true;
            std::cout << "Server started on " << getLocalIP() << ":" << port_ << std::endl;

            std::thread accept_thread([this]()
                                      { acceptConnections(); });
            accept_thread.detach();
        }

        void Server::acceptConnections()
        {
            while (running_)
            {
                sockaddr_in client_addr{};
                socklen_t client_len = sizeof(client_addr);
                int client_socket = accept(server_socket_, (struct sockaddr *)&client_addr, &client_len);

                if (client_socket >= 0)
                {
                    std::cout << "New connection from " << inet_ntoa(client_addr.sin_addr) << std::endl;

                    std::lock_guard<std::mutex> lock(clients_mutex_);
                    client_sockets_.push_back(client_socket);

                    std::thread client_thread([this, client_socket]()
                                              { handleClient(client_socket); });
                    client_thread.detach();
                }
            }
        }

        void Server::handleClient(int client_socket)
        {
            while (running_)
            {
                MessageHeader header;
                ssize_t bytes_read = recv(client_socket, &header, sizeof(header), 0);

                if (bytes_read <= 0)
                    break;

                std::vector<uint8_t> message_data(header.size - sizeof(header));
                bytes_read = recv(client_socket, message_data.data(), message_data.size(), 0);

                if (bytes_read <= 0)
                    break;

                processMessage(header.type, message_data.data(), client_socket);
            }

            std::lock_guard<std::mutex> lock(clients_mutex_);
            auto it = std::find(client_sockets_.begin(), client_sockets_.end(), client_socket);
            if (it != client_sockets_.end())
            {
                client_sockets_.erase(it);
            }
            close(client_socket);
        }

        void Server::processMessage(uint8_t type, uint8_t *data, int sender_socket)
        {
            switch (static_cast<MessageType>(type))
            {
            case MessageType::SPEED_DATA:
            {
                auto speed_data = reinterpret_cast<SpeedMessage *>(data - sizeof(MessageHeader));
                car_state_->updateSpeed(speed_data->current_speed);
                broadcastMessage(speed_data, sizeof(SpeedMessage), sender_socket);
                break;
            }
            case MessageType::WHEEL_DATA:
            {
                auto wheel_data = reinterpret_cast<WheelMessage *>(data - sizeof(MessageHeader));
                car_state_->updateWheels(wheel_data->left_wheel_speed,
                                         wheel_data->right_wheel_speed);
                broadcastMessage(wheel_data, sizeof(WheelMessage), sender_socket);
                break;
            }
            case MessageType::MOTOR_DATA:
            {
                auto motor_data = reinterpret_cast<MotorMessage *>(data - sizeof(MessageHeader));
                car_state_->updateMotor(motor_data->direction, motor_data->power);
                broadcastMessage(motor_data, sizeof(MotorMessage), sender_socket);
                break;
            }
            }
        }

        void Server::broadcastMessage(void *data, size_t size, int sender_socket)
        {
            std::lock_guard<std::mutex> lock(clients_mutex_);
            for (int client : client_sockets_)
            {
                if (client != sender_socket)
                {
                    send(client, data, size, 0);
                }
            }
        }

        std::string Server::getLocalIP() const
        {
            int sock = socket(AF_INET, SOCK_DGRAM, 0);
            if (sock == -1)
                return "unknown";

            struct sockaddr_in serv
            {
            };
            serv.sin_family = AF_INET;
            serv.sin_addr.s_addr = inet_addr("8.8.8.8");
            serv.sin_port = htons(53);

            if (connect(sock, (const struct sockaddr *)&serv, sizeof(serv)) == -1)
            {
                close(sock);
                return "unknown";
            }

            struct sockaddr_in name
            {
            };
            socklen_t namelen = sizeof(name);
            getsockname(sock, (struct sockaddr *)&name, &namelen);

            close(sock);
            return inet_ntoa(name.sin_addr);
        }

        void Server::stop()
        {
            running_ = false;

            std::lock_guard<std::mutex> lock(clients_mutex_);
            for (int client : client_sockets_)
            {
                close(client);
            }
            close(server_socket_);
        }

        Server::~Server()
        {
            stop();
        }

    } // namespace Network
} // namespace CarServer
