#pragma once

#include <mutex>
#include <cstdint>

namespace CarServer
{
    namespace Car
    {

        class CarState
        {
        public:
            struct State
            {
                int16_t speed;
                int16_t left_wheel;
                int16_t right_wheel;
                int8_t motor_direction;
                uint8_t motor_power;

                State() : speed(0), left_wheel(0), right_wheel(0),
                          motor_direction(0), motor_power(0) {}
            };

            CarState() = default;

            void updateSpeed(int16_t new_speed)
            {
                std::lock_guard<std::mutex> lock(mutex_);
                state_.speed = new_speed;
            }

            void updateWheels(int16_t left, int16_t right)
            {
                std::lock_guard<std::mutex> lock(mutex_);
                state_.left_wheel = left;
                state_.right_wheel = right;
            }

            void updateMotor(int8_t direction, uint8_t power)
            {
                std::lock_guard<std::mutex> lock(mutex_);
                state_.motor_direction = direction;
                state_.motor_power = power;
            }

            State getState() const
            {
                std::lock_guard<std::mutex> lock(mutex_);
                return state_;
            }

        private:
            mutable std::mutex mutex_;
            State state_;
        };

    } // namespace Car
} // namespace CarServer
