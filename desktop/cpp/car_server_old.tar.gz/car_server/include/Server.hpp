#pragma once

#include <vector>
#include <thread>
#include <atomic>
#include <memory>
#include "CarState.hpp"
#include "MessageTypes.hpp"

namespace CarServer
{
    namespace Network
    {

        class Server
        {
        public:
            Server(uint16_t port = 4206);
            ~Server();

            void start();
            void stop();
            std::string getLocalIP() const;

        private:
            void acceptConnections();
            void handleClient(int client_socket);
            void processMessage(uint8_t type, uint8_t *data, int sender_socket);
            void broadcastMessage(void *data, size_t size, int sender_socket);

            int server_socket_;
            std::vector<int> client_sockets_;
            std::mutex clients_mutex_;
            std::atomic<bool> running_;
            std::shared_ptr<Car::CarState> car_state_;
            uint16_t port_;
        };

    } // namespace Network
} // namespace CarServer
