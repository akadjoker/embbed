#pragma once

#include <cstdint>

namespace CarServer
{
    namespace Network
    {

        // Base message header
        struct MessageHeader
        {
            uint16_t size; // Total message size
            uint8_t type;  // Message type

            MessageHeader(uint8_t t = 0) : size(sizeof(MessageHeader)), type(t) {}
        };

        // Message types enum
        enum class MessageType : uint8_t
        {
            SPEED_DATA = 1,
            WHEEL_DATA = 2,
            MOTOR_DATA = 3,
            CLIENT_INFO = 4
        };

        // Specific message structures
        struct SpeedMessage
        {
            MessageHeader header;
            int16_t current_speed;

            SpeedMessage() : header(static_cast<uint8_t>(MessageType::SPEED_DATA))
            {
                header.size = sizeof(SpeedMessage);
            }
        };

        struct WheelMessage
        {
            MessageHeader header;
            int16_t left_wheel_speed;
            int16_t right_wheel_speed;

            WheelMessage() : header(static_cast<uint8_t>(MessageType::WHEEL_DATA))
            {
                header.size = sizeof(WheelMessage);
            }
        };

        struct MotorMessage
        {
            MessageHeader header;
            int8_t direction; // -1: reverse, 0: stopped, 1: forward
            uint8_t power;    // 0-100%

            MotorMessage() : header(static_cast<uint8_t>(MessageType::MOTOR_DATA))
            {
                header.size = sizeof(MotorMessage);
            }
        };

    } // namespace Network
} // namespace CarServer
